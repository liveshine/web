import { Post } from "./lib/db";

export const posts: Post[] = [];

export const categories = [
  { name: 'Mathematics', count: 0 },
  { name: 'Physics', count: 0 },
  { name: 'Computer Science', count: 0 }
];

export const learningPaths = [
  {
    id: '1',
    title: 'Introduction to Calculus',
    description: 'Learn the basics of limits, derivatives, and integrals.',
    postCount: 0
  }
];
